# Actual TCN vs PatchTST results — Anand Vihar air quality

## Executive result
In this preliminary local CPU run, **PatchTST achieved lower held-out forecasting error than TCN**, while TCN was substantially faster to train and infer. This is a one-seed, 10-epoch-capped experiment—not the final project ranking.

- PatchTST reduced macro-normalized MAE by **17.4%** versus TCN.
- PatchTST reduced macro-normalized RMSE by **10.3%** versus TCN.
- PatchTST had lower normalized MAE on **11 of 11 pollutants**.
- TCN trained in **59.9 s**; PatchTST trained in **281.9 s** (about **4.7×** as long).
- PatchTST single-sample inference was **47.7%** slower than TCN in this CPU benchmark.

## Model-level comparison

| Model    |   Macro normalized MAE (lower is better) |   Macro normalized RMSE (lower is better) |   Macro mean R² (higher is better) |   Training time (seconds) |   Single-sample inference (ms) |   Trainable parameters |   Checkpoint size (MB) |   Epochs completed |   Best validation masked MSE |
|:---------|-----------------------------------------:|------------------------------------------:|-----------------------------------:|--------------------------:|-------------------------------:|-----------------------:|-----------------------:|-------------------:|-----------------------------:|
| TCN      |                                   0.3663 |                                    0.5128 |                            -0.0577 |                   59.9238 |                         0.9907 |                 106568 |                 0.4154 |                 10 |                       0.8529 |
| PatchTST |                                   0.3027 |                                    0.4598 |                             0.1705 |                  281.9420 |                         1.4637 |                 118488 |                 0.4681 |                  6 |                       0.8402 |

## Experiment configuration
- Dataset: cleaned Anand Vihar, Delhi hourly observations from 2025-01-01 00:00 to 2026-08-31 23:00.
- Variables: 11 pollutants, both inputs and targets.
- Input context: 24 hours. Forecast horizon: next 24 hours.
- Chronological split: 10,214 training rows (70%), 2,189 validation rows (15%), 2,189 test rows (15%).
- Test target period: 2026-06-01 19:00:00 to 2026-08-31 23:00:00.
- Training: AdamW, learning rate 0.001, batch size 64, maximum 10 epochs, early-stopping patience 4, seed 42. TCN completed 10 epochs; PatchTST completed 6 epochs.
- Missing input values were imputed using training-period medians. Robust scaling was fitted on training-period observations only. Missing future target cells were masked out of loss and metrics.
- Both models evaluated on 2,166 rolling test windows with 544,067 observed target cells.
- Hardware: local CPU only (no CUDA GPU). Runtime figures should not be compared with T4 GPU notebook runs.

## How to read the metrics
The pollutants use different measurement units and scales. The aggregate MAE/RMSE are therefore macro-averages of each pollutant's error divided by its training-period IQR. Lower is better. Macro R² is the average of the 11 pollutant-wise R² scores; higher is better, and a negative value means performance is poor relative to a mean baseline for at least a substantial portion of variables. Pollutant-wise absolute-unit scores are in `pollutant_wise_comparison.csv`.

Test windows use rolling hourly origins, so target timestamps can appear in multiple forecast windows. The results measure rolling-origin multi-horizon forecasting, not a set of independent hourly errors.

## Preliminary conclusion
**Accuracy:** PatchTST is the stronger candidate on this run. **Efficiency:** TCN is the lighter, faster candidate. If the project's next stage prioritizes accuracy, PatchTST is the better base-model candidate to carry forward; if it prioritizes runtime and model simplicity, TCN remains competitive. Confirm this with the full planned Colab GPU training (and ideally multiple seeds) before making a final research claim.
