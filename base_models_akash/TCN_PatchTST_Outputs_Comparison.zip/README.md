# Smart Air Quality Monitoring — Actual TCN and PatchTST Results

This folder contains actual preliminary training outputs from the TCN and PatchTST base models on the combined Anand Vihar, Delhi hourly dataset (2025 through August 2026).

## Folder structure

- `TCN/` — TCN model checkpoint, pollutant metrics, horizon metrics, training history, PM2.5 forecast example, full held-out predictions, run summary and plots.
- `PatchTST/` — equivalent outputs for PatchTST.
- `Comparison/` — side-by-side summary tables, pollutant-level comparison, visualisations and interpretation report.

## Preliminary result

PatchTST had lower macro-normalised MAE and RMSE on this run (0.3027 and 0.4598) than TCN (0.3663 and 0.5128). PatchTST also had lower normalised MAE for all 11 pollutants. TCN was faster on this CPU run: 59.9 seconds training versus 281.9 seconds for PatchTST, and 0.991 ms versus 1.464 ms per single-sample inference.

## Experimental limitations

- This is a preliminary single-seed local CPU run, not a final model ranking.
- Both models used the same chronological train/validation/test split, 24-hour input, 24-hour forecasting horizon, masked missing-target loss and 10-epoch cap with early-stopping patience 4.
- TCN completed 10 epochs; PatchTST early-stopped after 6 epochs.
- Training and inference timings are CPU-only and must not be compared with GPU timings from Google Colab.
- Repeat both experiments under the team's standard Colab GPU setup and preferably across multiple random seeds before reporting a final winner.

See `Comparison/comparison_report.md` for the full metrics and interpretation.
